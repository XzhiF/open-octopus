import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import type { Execution, ExecutionStatus } from "@/lib/types"
import {
  CheckCircle2,
  XCircle,
  Clock,
  Play,
  RotateCcw,
  ArrowRight,
  Timer,
} from "lucide-react"

interface RecentExecutionsProps {
  executions: Execution[]
}

const statusConfig: Record<
  ExecutionStatus,
  { icon: React.ElementType; label: string; variant: "default" | "secondary" | "destructive" | "outline" }
> = {
  completed: { icon: CheckCircle2, label: "完成", variant: "default" },
  failed: { icon: XCircle, label: "失败", variant: "destructive" },
  running: { icon: Play, label: "运行中", variant: "secondary" },
  queued: { icon: Clock, label: "队列中", variant: "outline" },
  cancelled: { icon: XCircle, label: "已取消", variant: "outline" },
  rolling_back: { icon: RotateCcw, label: "回滚中", variant: "secondary" },
}

function formatDuration(seconds?: number): string {
  if (!seconds) return "-"
  if (seconds < 60) return `${seconds}s`
  const minutes = Math.floor(seconds / 60)
  const remainingSeconds = seconds % 60
  if (minutes < 60) return `${minutes}m ${remainingSeconds}s`
  const hours = Math.floor(minutes / 60)
  const remainingMinutes = minutes % 60
  return `${hours}h ${remainingMinutes}m`
}

function formatTime(dateString: string): string {
  const date = new Date(dateString)
  return date.toLocaleTimeString("zh-CN", {
    hour: "2-digit",
    minute: "2-digit",
  })
}

function ExecutionRow({ execution }: { execution: Execution }) {
  const config = statusConfig[execution.status]
  const StatusIcon = config.icon

  return (
    <Link
      href={`/workspaces/${execution.workspaceId}?execution=${execution.id}`}
      className="group flex items-center gap-4 rounded-lg px-3 py-2.5 transition-colors hover:bg-accent"
    >
      {/* Status Icon */}
      <div
        className={`flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full ${
          execution.status === "completed"
            ? "bg-emerald-500/10 text-emerald-500"
            : execution.status === "failed"
              ? "bg-destructive/10 text-destructive"
              : "bg-muted text-muted-foreground"
        }`}
      >
        <StatusIcon className="h-4 w-4" />
      </div>

      {/* Info */}
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="truncate font-medium">{execution.workflowName}</span>
          <Badge variant={config.variant} className="flex-shrink-0 text-xs">
            {config.label}
          </Badge>
        </div>
        <p className="truncate text-sm text-muted-foreground">
          {execution.workspaceName}
        </p>
      </div>

      {/* Duration */}
      <div className="flex flex-shrink-0 items-center gap-1 text-sm text-muted-foreground">
        <Timer className="h-3.5 w-3.5" />
        <span className="tabular-nums">{formatDuration(execution.duration)}</span>
      </div>

      {/* Time */}
      <div className="w-16 flex-shrink-0 text-right text-sm tabular-nums text-muted-foreground">
        {formatTime(execution.startedAt)}
      </div>

      {/* Arrow */}
      <ArrowRight className="h-4 w-4 flex-shrink-0 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
    </Link>
  )
}

export function RecentExecutions({ executions }: RecentExecutionsProps) {
  // Filter to show only completed/failed executions (not running/queued)
  const completedExecutions = executions.filter(
    (e) => e.status === "completed" || e.status === "failed" || e.status === "cancelled"
  )

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base font-semibold">最近执行记录</CardTitle>
          <Button variant="ghost" size="sm" asChild>
            <Link href="/executions">
              查看全部
              <ArrowRight className="ml-1 h-3.5 w-3.5" />
            </Link>
          </Button>
        </div>
      </CardHeader>
      <CardContent className="px-3">
        {completedExecutions.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <CheckCircle2 className="h-10 w-10 text-muted-foreground/50" />
            <p className="mt-2 text-sm text-muted-foreground">
              暂无执行记录
            </p>
          </div>
        ) : (
          <div className="space-y-1">
            {completedExecutions.map((execution) => (
              <ExecutionRow key={execution.id} execution={execution} />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
