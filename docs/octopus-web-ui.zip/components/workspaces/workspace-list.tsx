"use client"

import { useState, useMemo } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { WorkspaceCard } from "./workspace-card"
import { CreateWorkspaceDialog } from "./create-workspace-dialog"
import type { Workspace, WorkspaceStatus } from "@/lib/types"
import { Search, Plus, LayoutGrid, List } from "lucide-react"

interface WorkspaceListProps {
  workspaces: Workspace[]
}

export function WorkspaceList({ workspaces }: WorkspaceListProps) {
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState<WorkspaceStatus | "all">("all")
  const [isCreateOpen, setIsCreateOpen] = useState(false)

  const filteredWorkspaces = useMemo(() => {
    return workspaces.filter((ws) => {
      const matchesSearch =
        ws.name.toLowerCase().includes(search.toLowerCase()) ||
        ws.description.toLowerCase().includes(search.toLowerCase())
      const matchesStatus = statusFilter === "all" || ws.status === statusFilter
      return matchesSearch && matchesStatus
    })
  }, [workspaces, search, statusFilter])

  return (
    <div className="space-y-6">
      {/* Toolbar */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 items-center gap-3">
          {/* Search */}
          <div className="relative flex-1 sm:max-w-xs">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="搜索工作空间..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>

          {/* Status Filter */}
          <Select
            value={statusFilter}
            onValueChange={(value) => setStatusFilter(value as WorkspaceStatus | "all")}
          >
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="状态" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部状态</SelectItem>
              <SelectItem value="active">活跃</SelectItem>
              <SelectItem value="inactive">未激活</SelectItem>
              <SelectItem value="error">异常</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <div className="flex items-center rounded-md border border-input">
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-r-none">
              <LayoutGrid className="h-4 w-4" />
              <span className="sr-only">网格视图</span>
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-l-none border-l">
              <List className="h-4 w-4" />
              <span className="sr-only">列表视图</span>
            </Button>
          </div>
          <Button onClick={() => setIsCreateOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            新建工作空间
          </Button>
        </div>
      </div>

      {/* Results Info */}
      <div className="text-sm text-muted-foreground">
        共 {filteredWorkspaces.length} 个工作空间
        {search && ` · 搜索 "${search}"`}
      </div>

      {/* Grid */}
      {filteredWorkspaces.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-lg border border-dashed py-12 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
            <Search className="h-6 w-6 text-muted-foreground" />
          </div>
          <h3 className="mt-4 text-lg font-medium">未找到工作空间</h3>
          <p className="mt-1 text-sm text-muted-foreground">
            {search ? "尝试调整搜索条件" : "创建您的第一个工作空间"}
          </p>
          {!search && (
            <Button className="mt-4" onClick={() => setIsCreateOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              新建工作空间
            </Button>
          )}
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filteredWorkspaces.map((workspace) => (
            <WorkspaceCard key={workspace.id} workspace={workspace} />
          ))}
        </div>
      )}

      {/* Create Dialog */}
      <CreateWorkspaceDialog open={isCreateOpen} onOpenChange={setIsCreateOpen} />
    </div>
  )
}
