"use client"

import { useState, useRef, useEffect } from "react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import type { Workflow, Execution, StepExecution, StepExecutionStatus } from "@/lib/types"
import {
  Play,
  CheckCircle2,
  XCircle,
  Clock,
  Loader2,
  SkipForward,
  Terminal,
  Maximize2,
  Minimize2,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  ChevronDown,
  ChevronRight,
} from "lucide-react"

interface WorkflowFlowPanelProps {
  workflows: Workflow[]
  executions: Execution[]
  selectedExecutionId?: string
  onExecutionSelect?: (execution: Execution) => void
}

const statusConfig: Record<
  "queued" | "running" | "completed" | "failed" | "cancelled",
  { color: string; bgColor: string; borderColor: string; label: string }
> = {
  queued: { color: "text-blue-600", bgColor: "bg-blue-50", borderColor: "border-blue-200", label: "排队中" },
  running: { color: "text-amber-600", bgColor: "bg-amber-50", borderColor: "border-amber-300", label: "运行中" },
  completed: { color: "text-emerald-600", bgColor: "bg-emerald-50", borderColor: "border-emerald-200", label: "已完成" },
  failed: { color: "text-red-600", bgColor: "bg-red-50", borderColor: "border-red-200", label: "失败" },
  cancelled: { color: "text-gray-600", bgColor: "bg-gray-50", borderColor: "border-gray-200", label: "已取消" },
}

const stepStatusConfig: Record<
  StepExecutionStatus,
  { icon: React.ElementType; color: string; bgColor: string }
> = {
  pending: { icon: Clock, color: "text-muted-foreground", bgColor: "bg-muted" },
  running: { icon: Loader2, color: "text-amber-500", bgColor: "bg-amber-100" },
  completed: { icon: CheckCircle2, color: "text-emerald-500", bgColor: "bg-emerald-100" },
  failed: { icon: XCircle, color: "text-red-500", bgColor: "bg-red-100" },
  skipped: { icon: SkipForward, color: "text-muted-foreground", bgColor: "bg-muted" },
}

// Execution Node - represents a single workflow execution
function ExecutionNode({
  execution,
  workflow,
  isSelected,
  isExpanded,
  onSelect,
  onToggleExpand,
  position,
}: {
  execution: Execution
  workflow?: Workflow
  isSelected: boolean
  isExpanded: boolean
  onSelect: () => void
  onToggleExpand: () => void
  position: { x: number; y: number }
}) {
  const config = statusConfig[execution.status]
  const isRunning = execution.status === "running"
  const workflowName = workflow?.name || execution.workflowId

  return (
    <div
      className="absolute transition-all duration-300"
      style={{ left: position.x, top: position.y }}
    >
      {/* Main Node */}
      <div
        className={cn(
          "relative w-56 rounded-lg border-2 bg-card shadow-sm transition-all cursor-pointer",
          config.borderColor,
          isSelected && "ring-2 ring-primary ring-offset-2",
          isRunning && "animate-pulse"
        )}
        onClick={onSelect}
      >
        {/* Node Header */}
        <div className={cn("flex items-center gap-2 rounded-t-md px-3 py-2", config.bgColor)}>
          <div className="flex h-6 w-6 items-center justify-center rounded-full bg-card">
            {isRunning ? (
              <Loader2 className={cn("h-4 w-4 animate-spin", config.color)} />
            ) : execution.status === "completed" ? (
              <CheckCircle2 className={cn("h-4 w-4", config.color)} />
            ) : execution.status === "failed" ? (
              <XCircle className={cn("h-4 w-4", config.color)} />
            ) : execution.status === "queued" ? (
              <Clock className={cn("h-4 w-4", config.color)} />
            ) : (
              <SkipForward className={cn("h-4 w-4", config.color)} />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="truncate text-sm font-medium">{workflowName}</h4>
            <p className="text-xs text-muted-foreground">
              {new Date(execution.startTime).toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })}
            </p>
          </div>
          <Badge variant="outline" className={cn("text-xs", config.color)}>
            {config.label}
          </Badge>
        </div>

        {/* Progress Bar (for running) */}
        {isRunning && (
          <div className="h-1 bg-muted">
            <div
              className="h-full bg-amber-500 transition-all duration-500"
              style={{ width: `${execution.progress}%` }}
            />
          </div>
        )}

        {/* Node Body */}
        <div className="p-3">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>步骤: {execution.steps.filter(s => s.status === "completed").length}/{execution.steps.length}</span>
            {execution.progress !== undefined && (
              <span className="tabular-nums">{execution.progress}%</span>
            )}
          </div>

          {/* Expand Button */}
          <Button
            variant="ghost"
            size="sm"
            className="mt-2 w-full h-7 text-xs"
            onClick={(e) => {
              e.stopPropagation()
              onToggleExpand()
            }}
          >
            {isExpanded ? (
              <>
                <ChevronDown className="mr-1 h-3 w-3" />
                收起详情
              </>
            ) : (
              <>
                <ChevronRight className="mr-1 h-3 w-3" />
                展开详情
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Expanded Details Panel */}
      {isExpanded && (
        <div className="mt-2 w-72 rounded-lg border bg-card p-3 shadow-lg">
          <h5 className="mb-2 text-xs font-medium text-muted-foreground uppercase tracking-wider">
            执行步骤
          </h5>
          <div className="space-y-2">
            {execution.steps.map((step, idx) => {
              const stepConfig = stepStatusConfig[step.status]
              const Icon = stepConfig.icon
              const workflowStep = workflow?.steps.find(s => s.id === step.stepId)
              return (
                <div
                  key={step.stepId}
                  className={cn(
                    "flex items-start gap-2 rounded-md p-2",
                    stepConfig.bgColor
                  )}
                >
                  <div className="flex h-5 w-5 items-center justify-center rounded-full bg-card">
                    <Icon
                      className={cn(
                        "h-3 w-3",
                        stepConfig.color,
                        step.status === "running" && "animate-spin"
                      )}
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-medium truncate">
                        {workflowStep?.name || step.stepId}
                      </span>
                      {step.duration !== undefined && (
                        <span className="text-xs text-muted-foreground tabular-nums">
                          {step.duration}s
                        </span>
                      )}
                    </div>
                    {step.error && (
                      <p className="mt-1 text-xs text-red-600 truncate">{step.error}</p>
                    )}
                  </div>
                </div>
              )
            })}
          </div>

          {/* Logs Section */}
          {execution.logs.length > 0 && (
            <div className="mt-3 pt-3 border-t">
              <div className="flex items-center gap-1 text-xs text-muted-foreground mb-2">
                <Terminal className="h-3 w-3" />
                <span>日志输出</span>
              </div>
              <div className="max-h-32 overflow-y-auto rounded bg-muted/50 p-2 font-mono text-xs">
                {execution.logs.slice(-5).map((log, i) => (
                  <div key={i} className="text-muted-foreground">{log}</div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// SVG Connector Lines
function ConnectorLine({
  from,
  to,
  status,
}: {
  from: { x: number; y: number }
  to: { x: number; y: number }
  status: "pending" | "active" | "completed" | "failed"
}) {
  const strokeColor = {
    pending: "#d1d5db",
    active: "#f59e0b",
    completed: "#10b981",
    failed: "#ef4444",
  }[status]

  const midY = (from.y + to.y) / 2

  return (
    <svg
      className="absolute top-0 left-0 w-full h-full pointer-events-none"
      style={{ overflow: "visible" }}
    >
      <defs>
        <marker
          id={`arrowhead-${status}`}
          markerWidth="10"
          markerHeight="7"
          refX="9"
          refY="3.5"
          orient="auto"
        >
          <polygon points="0 0, 10 3.5, 0 7" fill={strokeColor} />
        </marker>
      </defs>
      <path
        d={`M ${from.x} ${from.y} C ${from.x} ${midY}, ${to.x} ${midY}, ${to.x} ${to.y}`}
        fill="none"
        stroke={strokeColor}
        strokeWidth={status === "active" ? 3 : 2}
        strokeDasharray={status === "pending" ? "5,5" : "none"}
        markerEnd={`url(#arrowhead-${status})`}
        className={cn(status === "active" && "animate-pulse")}
      />
    </svg>
  )
}

export function WorkflowFlowPanel({
  workflows,
  executions,
  selectedExecutionId,
  onExecutionSelect,
}: WorkflowFlowPanelProps) {
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [zoom, setZoom] = useState(1)
  const containerRef = useRef<HTMLDivElement>(null)

  // Sort executions by start time (newest first for display, but we'll reverse for flow)
  const sortedExecutions = [...executions].sort(
    (a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime()
  )

  // Calculate positions for each execution node (flow from top to bottom)
  const nodePositions = sortedExecutions.map((_, index) => ({
    x: 120 + (index % 2) * 40, // Slight zigzag for visual interest
    y: 40 + index * 180,
  }))

  const handleZoomIn = () => setZoom((z) => Math.min(z + 0.1, 1.5))
  const handleZoomOut = () => setZoom((z) => Math.max(z - 0.1, 0.5))
  const handleResetZoom = () => setZoom(1)

  const getWorkflowById = (id: string) => workflows.find((w) => w.id === id)

  return (
    <div className="flex h-full flex-col border-x border-border bg-muted/30">
      {/* Header */}
      <div className="flex h-10 items-center justify-between border-b border-border bg-background px-3">
        <div className="flex items-center gap-2">
          <Play className="h-4 w-4 text-muted-foreground" />
          <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            执行流程
          </span>
          <Badge variant="secondary" className="text-xs">
            {executions.length} 次执行
          </Badge>
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleZoomOut}>
            <ZoomOut className="h-3.5 w-3.5" />
          </Button>
          <span className="w-12 text-center text-xs text-muted-foreground tabular-nums">
            {Math.round(zoom * 100)}%
          </span>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleZoomIn}>
            <ZoomIn className="h-3.5 w-3.5" />
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleResetZoom}>
            <RotateCcw className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>

      {/* Flow Canvas */}
      <ScrollArea className="flex-1">
        <div
          ref={containerRef}
          className="relative min-h-full p-4"
          style={{
            transform: `scale(${zoom})`,
            transformOrigin: "top left",
            width: `${100 / zoom}%`,
            minHeight: sortedExecutions.length * 180 + 100,
          }}
        >
          {sortedExecutions.length === 0 ? (
            <div className="flex h-full min-h-[400px] flex-col items-center justify-center text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                <Play className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="mt-4 text-lg font-medium">暂无执行记录</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                点击"执行工作流"开始第一次执行
              </p>
            </div>
          ) : (
            <>
              {/* Connector Lines */}
              {sortedExecutions.slice(0, -1).map((execution, index) => {
                const nextExecution = sortedExecutions[index + 1]
                const fromPos = nodePositions[index]
                const toPos = nodePositions[index + 1]

                let lineStatus: "pending" | "active" | "completed" | "failed" = "completed"
                if (execution.status === "running") lineStatus = "active"
                else if (execution.status === "failed") lineStatus = "failed"
                else if (nextExecution?.status === "queued") lineStatus = "pending"

                return (
                  <ConnectorLine
                    key={`line-${execution.id}`}
                    from={{ x: fromPos.x + 112, y: fromPos.y + 100 }}
                    to={{ x: toPos.x + 112, y: toPos.y }}
                    status={lineStatus}
                  />
                )
              })}

              {/* Execution Nodes */}
              {sortedExecutions.map((execution, index) => (
                <ExecutionNode
                  key={execution.id}
                  execution={execution}
                  workflow={getWorkflowById(execution.workflowId)}
                  isSelected={selectedExecutionId === execution.id}
                  isExpanded={expandedId === execution.id}
                  onSelect={() => onExecutionSelect?.(execution)}
                  onToggleExpand={() =>
                    setExpandedId((prev) => (prev === execution.id ? null : execution.id))
                  }
                  position={nodePositions[index]}
                />
              ))}
            </>
          )}
        </div>
      </ScrollArea>
    </div>
  )
}
