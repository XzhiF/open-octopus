"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import type { FileNode } from "@/lib/types"
import {
  ChevronRight,
  ChevronDown,
  File,
  Folder,
  FolderOpen,
  FileCode,
  FileJson,
  FileText,
  RefreshCw,
  Plus,
} from "lucide-react"

interface SidebarFileTreeProps {
  files: FileNode[]
  onFileSelect?: (file: FileNode) => void
  selectedPath?: string
}

const fileIconMap: Record<string, React.ElementType> = {
  tsx: FileCode,
  ts: FileCode,
  js: FileCode,
  jsx: FileCode,
  json: FileJson,
  yaml: FileText,
  yml: FileText,
  md: FileText,
}

function FileTreeNode({
  node,
  level = 0,
  onFileSelect,
  selectedPath,
}: {
  node: FileNode
  level?: number
  onFileSelect?: (file: FileNode) => void
  selectedPath?: string
}) {
  const [isExpanded, setIsExpanded] = useState(node.isExpanded ?? false)
  const isDirectory = node.type === "directory"
  const isSelected = selectedPath === node.path
  const FileIcon = node.extension ? fileIconMap[node.extension] || File : File

  const handleClick = () => {
    if (isDirectory) {
      setIsExpanded(!isExpanded)
    } else {
      onFileSelect?.(node)
    }
  }

  return (
    <div>
      <button
        onClick={handleClick}
        className={cn(
          "flex w-full items-center gap-1 rounded-sm px-2 py-1 text-left text-sm transition-colors hover:bg-accent",
          isSelected && "bg-accent text-accent-foreground"
        )}
        style={{ paddingLeft: `${level * 12 + 8}px` }}
      >
        {isDirectory ? (
          <>
            {isExpanded ? (
              <ChevronDown className="h-3.5 w-3.5 flex-shrink-0 text-muted-foreground" />
            ) : (
              <ChevronRight className="h-3.5 w-3.5 flex-shrink-0 text-muted-foreground" />
            )}
            {isExpanded ? (
              <FolderOpen className="h-4 w-4 flex-shrink-0 text-amber-500" />
            ) : (
              <Folder className="h-4 w-4 flex-shrink-0 text-amber-500" />
            )}
          </>
        ) : (
          <>
            <span className="w-3.5" />
            <FileIcon className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
          </>
        )}
        <span className="truncate">{node.name}</span>
      </button>
      {isDirectory && isExpanded && node.children && (
        <div>
          {node.children.map((child) => (
            <FileTreeNode
              key={child.id}
              node={child}
              level={level + 1}
              onFileSelect={onFileSelect}
              selectedPath={selectedPath}
            />
          ))}
        </div>
      )}
    </div>
  )
}

export function SidebarFileTree({ files, onFileSelect, selectedPath }: SidebarFileTreeProps) {
  return (
    <div className="flex h-full flex-col border-r border-border bg-sidebar">
      {/* Header */}
      <div className="flex h-10 items-center justify-between border-b border-border px-3">
        <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          文件
        </span>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-6 w-6">
            <Plus className="h-3.5 w-3.5" />
            <span className="sr-only">新建文件</span>
          </Button>
          <Button variant="ghost" size="icon" className="h-6 w-6">
            <RefreshCw className="h-3.5 w-3.5" />
            <span className="sr-only">刷新</span>
          </Button>
        </div>
      </div>

      {/* Tree */}
      <ScrollArea className="flex-1">
        <div className="p-2">
          {files.map((node) => (
            <FileTreeNode
              key={node.id}
              node={node}
              onFileSelect={onFileSelect}
              selectedPath={selectedPath}
            />
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}
