"use client"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { Execution, StepExecution, StepExecutionStatus } from "@/lib/types"
import {
  Play,
  CheckCircle2,
  XCircle,
  Clock,
  Loader2,
  SkipForward,
  ChevronRight,
  Terminal,
  StopCircle,
  RotateCcw,
} from "lucide-react"

interface ExecutionPanelProps {
  execution?: Execution
  onStop?: () => void
  onRollback?: () => void
}

const stepStatusConfig: Record<
  StepExecutionStatus,
  { icon: React.ElementType; color: string; label: string }
> = {
  pending: { icon: Clock, color: "text-muted-foreground", label: "等待中" },
  running: { icon: Loader2, color: "text-amber-500", label: "执行中" },
  completed: { icon: CheckCircle2, color: "text-emerald-500", label: "完成" },
  failed: { icon: XCircle, color: "text-destructive", label: "失败" },
  skipped: { icon: SkipForward, color: "text-muted-foreground", label: "跳过" },
}

function StepItem({ step, isLast }: { step: StepExecution; isLast: boolean }) {
  const config = stepStatusConfig[step.status]
  const Icon = config.icon
  const isRunning = step.status === "running"

  return (
    <div className="relative flex gap-3">
      {/* Timeline */}
      <div className="flex flex-col items-center">
        <div
          className={cn(
            "flex h-6 w-6 items-center justify-center rounded-full border-2",
            step.status === "completed" && "border-emerald-500 bg-emerald-500/10",
            step.status === "failed" && "border-destructive bg-destructive/10",
            step.status === "running" && "border-amber-500 bg-amber-500/10",
            step.status === "pending" && "border-border bg-muted",
            step.status === "skipped" && "border-border bg-muted"
          )}
        >
          <Icon
            className={cn(
              "h-3.5 w-3.5",
              config.color,
              isRunning && "animate-spin"
            )}
          />
        </div>
        {!isLast && (
          <div
            className={cn(
              "h-full w-0.5 flex-1",
              step.status === "completed" ? "bg-emerald-500" : "bg-border"
            )}
          />
        )}
      </div>

      {/* Content */}
      <div className="flex-1 pb-4">
        <div className="flex items-center justify-between">
          <span className="font-medium">{step.stepName}</span>
          <Badge variant="outline" className="text-xs">
            {config.label}
          </Badge>
        </div>
        {step.duration !== undefined && (
          <p className="mt-0.5 text-xs text-muted-foreground">
            耗时: {step.duration}s
          </p>
        )}
        {step.error && (
          <p className="mt-1 rounded bg-destructive/10 px-2 py-1 text-xs text-destructive">
            {step.error}
          </p>
        )}
      </div>
    </div>
  )
}

function ExecutionSteps({ steps }: { steps: StepExecution[] }) {
  return (
    <div className="space-y-0">
      {steps.map((step, index) => (
        <StepItem key={step.stepId} step={step} isLast={index === steps.length - 1} />
      ))}
    </div>
  )
}

function ExecutionLogs({ logs }: { logs: string[] }) {
  if (logs.length === 0) {
    return (
      <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
        暂无日志
      </div>
    )
  }

  return (
    <div className="font-mono text-xs">
      {logs.map((log, index) => (
        <div key={index} className="px-2 py-0.5 hover:bg-muted">
          {log}
        </div>
      ))}
    </div>
  )
}

export function ExecutionPanel({ execution, onStop, onRollback }: ExecutionPanelProps) {
  if (!execution) {
    return (
      <div className="flex h-full flex-col border-l border-border bg-sidebar">
        <div className="flex h-10 items-center border-b border-border px-3">
          <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            执行状态
          </span>
        </div>
        <div className="flex flex-1 flex-col items-center justify-center p-4 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
            <Play className="h-6 w-6 text-muted-foreground" />
          </div>
          <h3 className="mt-4 font-medium">无执行任务</h3>
          <p className="mt-1 text-sm text-muted-foreground">
            选择一个工作流开始执行
          </p>
          <Button className="mt-4" size="sm">
            <Play className="mr-2 h-4 w-4" />
            执行工作流
          </Button>
        </div>
      </div>
    )
  }

  const isRunning = execution.status === "running"
  const isFailed = execution.status === "failed"

  return (
    <div className="flex h-full flex-col border-l border-border bg-sidebar">
      {/* Header */}
      <div className="flex h-10 items-center justify-between border-b border-border px-3">
        <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          执行状态
        </span>
        <div className="flex items-center gap-1">
          {isRunning && (
            <Button variant="ghost" size="icon" className="h-6 w-6 text-destructive" onClick={onStop}>
              <StopCircle className="h-3.5 w-3.5" />
              <span className="sr-only">停止</span>
            </Button>
          )}
          {isFailed && (
            <Button variant="ghost" size="icon" className="h-6 w-6" onClick={onRollback}>
              <RotateCcw className="h-3.5 w-3.5" />
              <span className="sr-only">回滚</span>
            </Button>
          )}
        </div>
      </div>

      {/* Workflow Info */}
      <div className="border-b border-border p-3">
        <div className="flex items-center gap-2">
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
          <span className="font-medium">{execution.workflowName}</span>
        </div>
        <div className="mt-2 flex items-center gap-2">
          <Badge
            variant={
              execution.status === "completed"
                ? "default"
                : execution.status === "failed"
                  ? "destructive"
                  : "secondary"
            }
          >
            {execution.status === "completed" && "完成"}
            {execution.status === "failed" && "失败"}
            {execution.status === "running" && "运行中"}
            {execution.status === "queued" && "队列中"}
          </Badge>
          {execution.currentStep && (
            <span className="text-xs text-muted-foreground">
              当前: {execution.currentStep}
            </span>
          )}
        </div>
        {isRunning && (
          <div className="mt-3 flex items-center gap-2">
            <Progress value={execution.progress} className="h-1.5 flex-1" />
            <span className="text-xs tabular-nums text-muted-foreground">
              {execution.progress}%
            </span>
          </div>
        )}
      </div>

      {/* Tabs */}
      <Tabs defaultValue="steps" className="flex flex-1 flex-col overflow-hidden">
        <TabsList className="mx-3 mt-2 w-fit">
          <TabsTrigger value="steps" className="text-xs">
            步骤
          </TabsTrigger>
          <TabsTrigger value="logs" className="text-xs">
            <Terminal className="mr-1 h-3 w-3" />
            日志
          </TabsTrigger>
        </TabsList>
        <TabsContent value="steps" className="mt-0 flex-1 overflow-hidden">
          <ScrollArea className="h-full p-3">
            <ExecutionSteps steps={execution.steps} />
          </ScrollArea>
        </TabsContent>
        <TabsContent value="logs" className="mt-0 flex-1 overflow-hidden">
          <ScrollArea className="h-full bg-muted/50 p-2">
            <ExecutionLogs logs={execution.logs} />
          </ScrollArea>
        </TabsContent>
      </Tabs>
    </div>
  )
}
