"use client"

import { useState, useRef, useEffect } from "react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import type { ChatMessage, ChatSession } from "@/lib/types"
import {
  Send,
  Plus,
  Sparkles,
  User,
  Bot,
  Play,
  MoreHorizontal,
  Copy,
  RotateCcw,
  X,
  MessageSquare,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

interface ChatPanelProps {
  sessions: ChatSession[]
  activeSessionId: string
  messages: ChatMessage[]
  onSessionChange?: (sessionId: string) => void
  onCreateSession?: () => void
  onCloseSession?: (sessionId: string) => void
  onSendMessage?: (content: string) => void
}

function SessionTabs({
  sessions = [],
  activeSessionId,
  onSessionChange,
  onCreateSession,
  onCloseSession,
}: {
  sessions: ChatSession[]
  activeSessionId: string
  onSessionChange?: (sessionId: string) => void
  onCreateSession?: () => void
  onCloseSession?: (sessionId: string) => void
}) {
  const safeSessions = sessions || []
  
  return (
    <div className="flex items-center border-b border-border bg-muted/30">
      <ScrollArea className="flex-1" orientation="horizontal">
        <div className="flex items-center">
          {safeSessions.map((session) => (
            <div
              key={session.id}
              className={cn(
                "group relative flex h-9 items-center gap-2 border-r border-border px-3 cursor-pointer transition-colors",
                session.id === activeSessionId
                  ? "bg-background text-foreground"
                  : "text-muted-foreground hover:bg-background/50 hover:text-foreground"
              )}
              onClick={() => onSessionChange?.(session.id)}
            >
              <MessageSquare className="h-3.5 w-3.5 flex-shrink-0" />
              <span className="max-w-[100px] truncate text-xs font-medium">
                {session.title}
              </span>
              {sessions.length > 1 && (
                <button
                  className={cn(
                    "flex h-4 w-4 items-center justify-center rounded-sm transition-opacity",
                    "opacity-0 group-hover:opacity-100 hover:bg-muted"
                  )}
                  onClick={(e) => {
                    e.stopPropagation()
                    onCloseSession?.(session.id)
                  }}
                >
                  <X className="h-3 w-3" />
                </button>
              )}
              {/* Active indicator */}
              {session.id === activeSessionId && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
              )}
            </div>
          ))}
        </div>
      </ScrollArea>
      <Button
        variant="ghost"
        size="icon"
        className="h-9 w-9 flex-shrink-0 rounded-none border-l border-border"
        onClick={onCreateSession}
      >
        <Plus className="h-4 w-4" />
        <span className="sr-only">新建会话</span>
      </Button>
    </div>
  )
}

function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === "user"

  return (
    <div className={cn("group flex gap-3", isUser && "flex-row-reverse")}>
      {/* Avatar */}
      <div
        className={cn(
          "flex h-6 w-6 flex-shrink-0 items-center justify-center rounded",
          isUser ? "bg-primary text-primary-foreground" : "bg-muted"
        )}
      >
        {isUser ? (
          <User className="h-3.5 w-3.5" />
        ) : (
          <Bot className="h-3.5 w-3.5" />
        )}
      </div>

      {/* Content */}
      <div className={cn("flex max-w-[85%] flex-col gap-1", isUser && "items-end")}>
        <div
          className={cn(
            "rounded-lg px-3 py-2 text-sm",
            isUser
              ? "bg-primary text-primary-foreground"
              : "bg-muted text-foreground"
          )}
        >
          {message.type === "execution" && (
            <div className="mb-2 flex items-center gap-2">
              <Badge variant="secondary" className="gap-1 text-xs">
                <Play className="h-2.5 w-2.5" />
                执行任务
              </Badge>
            </div>
          )}
          <div className="whitespace-pre-wrap">{message.content}</div>
        </div>

        {/* Actions (on hover) */}
        <div className="flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
          <Button variant="ghost" size="icon" className="h-5 w-5">
            <Copy className="h-2.5 w-2.5" />
            <span className="sr-only">复制</span>
          </Button>
          {!isUser && (
            <Button variant="ghost" size="icon" className="h-5 w-5">
              <RotateCcw className="h-2.5 w-2.5" />
              <span className="sr-only">重新生成</span>
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}

export function ChatPanel({
  sessions,
  activeSessionId,
  messages,
  onSessionChange,
  onCreateSession,
  onCloseSession,
  onSendMessage,
}: ChatPanelProps) {
  const [input, setInput] = useState("")
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const scrollRef = useRef<HTMLDivElement>(null)

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    onSendMessage?.(input.trim())
    setInput("")
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSubmit(e)
    }
  }

  return (
    <div className="flex h-full flex-col bg-background border-x border-border">
      {/* Session Tabs */}
      <SessionTabs
        sessions={sessions}
        activeSessionId={activeSessionId}
        onSessionChange={onSessionChange}
        onCreateSession={onCreateSession}
        onCloseSession={onCloseSession}
      />

      {/* Chat Header */}
      <div className="flex h-9 items-center justify-between border-b border-border px-3 bg-muted/20">
        <div className="flex items-center gap-2">
          <Sparkles className="h-3.5 w-3.5 text-primary" />
          <span className="text-xs font-medium">Octopus AI</span>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-6 w-6">
              <MoreHorizontal className="h-3.5 w-3.5" />
              <span className="sr-only">更多</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem>清空会话</DropdownMenuItem>
            <DropdownMenuItem>导出记录</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-3" ref={scrollRef}>
        {messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
              <Sparkles className="h-5 w-5 text-primary" />
            </div>
            <h3 className="mt-3 text-sm font-medium">Octopus AI 助手</h3>
            <p className="mt-1 max-w-[180px] text-xs text-muted-foreground">
              我可以帮助您执行工作流、查看日志、管理文件
            </p>
            <div className="mt-3 flex flex-wrap justify-center gap-1.5">
              <Button variant="outline" size="sm" className="h-7 text-xs">
                执行部署
              </Button>
              <Button variant="outline" size="sm" className="h-7 text-xs">
                查看日志
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((message) => (
              <MessageBubble key={message.id} message={message} />
            ))}
          </div>
        )}
      </ScrollArea>

      {/* Input */}
      <div className="border-t border-border p-2">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <Textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="输入命令或问题..."
            className="min-h-[36px] max-h-[100px] resize-none text-sm"
            rows={1}
          />
          <Button type="submit" size="icon" className="h-9 w-9 flex-shrink-0" disabled={!input.trim()}>
            <Send className="h-4 w-4" />
            <span className="sr-only">发送</span>
          </Button>
        </form>
        <p className="mt-1 text-xs text-muted-foreground">
          Enter 发送 / Shift+Enter 换行
        </p>
      </div>
    </div>
  )
}
