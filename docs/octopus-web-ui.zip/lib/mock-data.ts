import type {
  Workspace,
  Workflow,
  Execution,
  ChatSession,
  ChatMessage,
  FileNode,
  DashboardStats,
} from "./types"

// ============ Workspaces ============
export const mockWorkspaces: Workspace[] = [
  {
    id: "ws-1",
    name: "E-Commerce Platform",
    description: "主要电商平台的部署和运维工作流",
    status: "active",
    projectCount: 3,
    workflowCount: 8,
    createdAt: "2024-01-15T08:00:00Z",
    updatedAt: "2024-03-10T14:30:00Z",
    lastActivityAt: "2024-03-10T14:30:00Z",
    path: "/projects/ecommerce-platform",
  },
  {
    id: "ws-2",
    name: "Data Pipeline",
    description: "数据处理和 ETL 工作流管理",
    status: "active",
    projectCount: 2,
    workflowCount: 5,
    createdAt: "2024-02-01T10:00:00Z",
    updatedAt: "2024-03-09T16:45:00Z",
    lastActivityAt: "2024-03-09T16:45:00Z",
    path: "/projects/data-pipeline",
  },
  {
    id: "ws-3",
    name: "ML Training Jobs",
    description: "机器学习模型训练和部署流程",
    status: "error",
    projectCount: 1,
    workflowCount: 3,
    createdAt: "2024-02-20T09:00:00Z",
    updatedAt: "2024-03-08T11:20:00Z",
    lastActivityAt: "2024-03-08T11:20:00Z",
    path: "/projects/ml-training",
  },
  {
    id: "ws-4",
    name: "Infrastructure",
    description: "基础设施自动化和配置管理",
    status: "active",
    projectCount: 4,
    workflowCount: 12,
    createdAt: "2024-01-05T12:00:00Z",
    updatedAt: "2024-03-10T09:15:00Z",
    lastActivityAt: "2024-03-10T09:15:00Z",
    path: "/projects/infrastructure",
  },
  {
    id: "ws-5",
    name: "Mobile App CI/CD",
    description: "移动应用持续集成和部署",
    status: "inactive",
    projectCount: 2,
    workflowCount: 4,
    createdAt: "2024-01-25T15:00:00Z",
    updatedAt: "2024-02-28T10:00:00Z",
    lastActivityAt: "2024-02-28T10:00:00Z",
    path: "/projects/mobile-cicd",
  },
]

// ============ Workflows ============
export const mockWorkflows: Workflow[] = [
  {
    id: "wf-1",
    projectId: "proj-1",
    workspaceId: "ws-1",
    name: "Deploy Production",
    description: "部署到生产环境的完整流程",
    status: "valid",
    steps: [
      { id: "s1", name: "Pull Latest Code", type: "shell", command: "git pull origin main" },
      { id: "s2", name: "Install Dependencies", type: "shell", command: "pnpm install", dependsOn: ["s1"] },
      { id: "s3", name: "Run Tests", type: "shell", command: "pnpm test", dependsOn: ["s2"] },
      { id: "s4", name: "Build Application", type: "shell", command: "pnpm build", dependsOn: ["s3"] },
      { id: "s5", name: "Deploy to Server", type: "script", command: "./scripts/deploy.sh", dependsOn: ["s4"] },
    ],
    yamlContent: `name: Deploy Production
steps:
  - name: Pull Latest Code
    run: git pull origin main
  - name: Install Dependencies
    run: pnpm install
  - name: Run Tests
    run: pnpm test
  - name: Build Application
    run: pnpm build
  - name: Deploy to Server
    run: ./scripts/deploy.sh`,
    createdAt: "2024-01-20T10:00:00Z",
    updatedAt: "2024-03-05T14:00:00Z",
  },
  {
    id: "wf-2",
    projectId: "proj-1",
    workspaceId: "ws-1",
    name: "Database Migration",
    description: "数据库迁移脚本执行",
    status: "valid",
    steps: [
      { id: "s1", name: "Backup Database", type: "script", command: "./scripts/backup-db.sh" },
      { id: "s2", name: "Run Migrations", type: "shell", command: "pnpm prisma migrate deploy", dependsOn: ["s1"] },
      { id: "s3", name: "Verify Migration", type: "shell", command: "pnpm prisma db pull", dependsOn: ["s2"] },
    ],
    yamlContent: `name: Database Migration
steps:
  - name: Backup Database
    run: ./scripts/backup-db.sh
  - name: Run Migrations
    run: pnpm prisma migrate deploy
  - name: Verify Migration
    run: pnpm prisma db pull`,
    createdAt: "2024-02-10T08:00:00Z",
    updatedAt: "2024-03-01T11:00:00Z",
  },
  {
    id: "wf-3",
    projectId: "proj-1",
    workspaceId: "ws-1",
    name: "API Health Check",
    description: "API 端点健康检查",
    status: "valid",
    steps: [
      { id: "s1", name: "Check Auth Service", type: "api", command: "curl https://api.example.com/auth/health" },
      { id: "s2", name: "Check User Service", type: "api", command: "curl https://api.example.com/users/health" },
      { id: "s3", name: "Check Order Service", type: "api", command: "curl https://api.example.com/orders/health" },
      { id: "s4", name: "Generate Report", type: "script", command: "./scripts/health-report.sh", dependsOn: ["s1", "s2", "s3"] },
    ],
    yamlContent: `name: API Health Check`,
    createdAt: "2024-02-15T08:00:00Z",
    updatedAt: "2024-03-08T11:00:00Z",
  },
  {
    id: "wf-4",
    projectId: "proj-1",
    workspaceId: "ws-1",
    name: "Backup & Cleanup",
    description: "系统备份和清理",
    status: "valid",
    steps: [
      { id: "s1", name: "Backup Logs", type: "shell", command: "tar -czf logs.tar.gz /var/log/app" },
      { id: "s2", name: "Backup Database", type: "script", command: "./scripts/backup-db.sh" },
      { id: "s3", name: "Upload to S3", type: "script", command: "./scripts/upload-s3.sh", dependsOn: ["s1", "s2"] },
      { id: "s4", name: "Cleanup Old Files", type: "shell", command: "find /tmp -mtime +7 -delete", dependsOn: ["s3"] },
    ],
    yamlContent: `name: Backup & Cleanup`,
    createdAt: "2024-01-25T08:00:00Z",
    updatedAt: "2024-03-02T09:00:00Z",
  },
  {
    id: "wf-5",
    projectId: "proj-2",
    workspaceId: "ws-2",
    name: "Data Sync Job",
    description: "数据同步任务",
    status: "valid",
    steps: [
      { id: "s1", name: "Extract Data", type: "script", command: "./scripts/extract.py" },
      { id: "s2", name: "Transform Data", type: "script", command: "./scripts/transform.py", dependsOn: ["s1"] },
      { id: "s3", name: "Load to Warehouse", type: "script", command: "./scripts/load.py", dependsOn: ["s2"] },
    ],
    yamlContent: `name: Data Sync Job`,
    createdAt: "2024-02-01T10:00:00Z",
    updatedAt: "2024-03-09T16:45:00Z",
  },
]

// ============ Executions ============
export const mockExecutions: Execution[] = [
  {
    id: "exec-1",
    workflowId: "wf-1",
    workflowName: "Deploy Production",
    workspaceId: "ws-1",
    workspaceName: "E-Commerce Platform",
    status: "running",
    progress: 60,
    currentStep: "Build Application",
    steps: [
      { stepId: "s1", stepName: "Pull Latest Code", status: "completed", startedAt: "2024-03-10T14:00:00Z", completedAt: "2024-03-10T14:00:30Z", duration: 30 },
      { stepId: "s2", stepName: "Install Dependencies", status: "completed", startedAt: "2024-03-10T14:00:30Z", completedAt: "2024-03-10T14:02:00Z", duration: 90 },
      { stepId: "s3", stepName: "Run Tests", status: "completed", startedAt: "2024-03-10T14:02:00Z", completedAt: "2024-03-10T14:05:00Z", duration: 180 },
      { stepId: "s4", stepName: "Build Application", status: "running", startedAt: "2024-03-10T14:05:00Z" },
      { stepId: "s5", stepName: "Deploy to Server", status: "pending" },
    ],
    startedAt: "2024-03-10T14:00:00Z",
    triggeredBy: "manual",
    logs: [
      "[14:00:00] Starting workflow: Deploy Production",
      "[14:00:00] Step 1: Pull Latest Code",
      "[14:00:30] Step 1 completed successfully",
      "[14:00:30] Step 2: Install Dependencies",
      "[14:02:00] Step 2 completed successfully",
      "[14:02:00] Step 3: Run Tests",
      "[14:05:00] Step 3 completed successfully (45 tests passed)",
      "[14:05:00] Step 4: Build Application",
      "[14:05:15] Building Next.js application...",
    ],
  },
  {
    id: "exec-2",
    workflowId: "wf-2",
    workflowName: "Database Migration",
    workspaceId: "ws-1",
    workspaceName: "E-Commerce Platform",
    status: "queued",
    progress: 0,
    steps: [
      { stepId: "s1", stepName: "Backup Database", status: "pending" },
      { stepId: "s2", stepName: "Run Migrations", status: "pending" },
      { stepId: "s3", stepName: "Verify Migration", status: "pending" },
    ],
    startedAt: "2024-03-10T14:10:00Z",
    triggeredBy: "chat",
    logs: [],
  },
  {
    id: "exec-3",
    workflowId: "wf-1",
    workflowName: "Data Sync Job",
    workspaceId: "ws-2",
    workspaceName: "Data Pipeline",
    status: "running",
    progress: 30,
    currentStep: "Transform Data",
    steps: [
      { stepId: "s1", stepName: "Extract Data", status: "completed", startedAt: "2024-03-10T13:30:00Z", completedAt: "2024-03-10T13:45:00Z", duration: 900 },
      { stepId: "s2", stepName: "Transform Data", status: "running", startedAt: "2024-03-10T13:45:00Z" },
      { stepId: "s3", stepName: "Load to Warehouse", status: "pending" },
    ],
    startedAt: "2024-03-10T13:30:00Z",
    triggeredBy: "schedule",
    logs: [
      "[13:30:00] Starting scheduled job: Data Sync",
      "[13:30:00] Extracting data from source...",
      "[13:45:00] Extraction complete. 1.2M records extracted.",
      "[13:45:00] Starting data transformation...",
    ],
  },
  {
    id: "exec-4",
    workflowId: "wf-1",
    workflowName: "Deploy Production",
    workspaceId: "ws-1",
    workspaceName: "E-Commerce Platform",
    status: "completed",
    progress: 100,
    steps: [
      { stepId: "s1", stepName: "Pull Latest Code", status: "completed", duration: 25 },
      { stepId: "s2", stepName: "Install Dependencies", status: "completed", duration: 85 },
      { stepId: "s3", stepName: "Run Tests", status: "completed", duration: 165 },
      { stepId: "s4", stepName: "Build Application", status: "completed", duration: 120 },
      { stepId: "s5", stepName: "Deploy to Server", status: "completed", duration: 45 },
    ],
    startedAt: "2024-03-10T10:00:00Z",
    completedAt: "2024-03-10T10:07:20Z",
    duration: 440,
    triggeredBy: "manual",
    logs: [],
  },
  {
    id: "exec-5",
    workflowId: "wf-1",
    workflowName: "Model Training",
    workspaceId: "ws-3",
    workspaceName: "ML Training Jobs",
    status: "failed",
    progress: 45,
    currentStep: "Train Model",
    steps: [
      { stepId: "s1", stepName: "Prepare Dataset", status: "completed", duration: 300 },
      { stepId: "s2", stepName: "Train Model", status: "failed", error: "CUDA out of memory" },
      { stepId: "s3", stepName: "Evaluate Model", status: "skipped" },
      { stepId: "s4", stepName: "Deploy Model", status: "skipped" },
    ],
    startedAt: "2024-03-10T08:00:00Z",
    completedAt: "2024-03-10T08:15:00Z",
    duration: 900,
    triggeredBy: "webhook",
    logs: [],
  },
  {
    id: "exec-6",
    workflowId: "wf-2",
    workflowName: "API Health Check",
    workspaceId: "ws-4",
    workspaceName: "Infrastructure",
    status: "completed",
    progress: 100,
    steps: [
      { stepId: "s1", stepName: "Check Endpoints", status: "completed", duration: 15 },
      { stepId: "s2", stepName: "Generate Report", status: "completed", duration: 5 },
    ],
    startedAt: "2024-03-10T12:00:00Z",
    completedAt: "2024-03-10T12:00:20Z",
    duration: 20,
    triggeredBy: "schedule",
    logs: [],
  },
]

// ============ Chat Sessions ============
export const mockChatSessions: ChatSession[] = [
  {
    id: "chat-1",
    workspaceId: "ws-1",
    title: "部署咨询",
    messages: [],
    createdAt: "2024-03-10T14:00:00Z",
    updatedAt: "2024-03-10T14:30:00Z",
    isActive: true,
  },
  {
    id: "chat-2",
    workspaceId: "ws-1",
    title: "数据库问题",
    messages: [],
    createdAt: "2024-03-09T10:00:00Z",
    updatedAt: "2024-03-09T11:30:00Z",
    isActive: false,
  },
  {
    id: "chat-3",
    workspaceId: "ws-1",
    title: "性能优化",
    messages: [],
    createdAt: "2024-03-08T09:00:00Z",
    updatedAt: "2024-03-08T10:00:00Z",
    isActive: false,
  },
  {
    id: "chat-4",
    workspaceId: "ws-2",
    title: "ETL 任务调试",
    messages: [],
    createdAt: "2024-03-07T14:00:00Z",
    updatedAt: "2024-03-07T15:30:00Z",
    isActive: true,
  },
]

export const mockChatMessages: ChatMessage[] = [
  {
    id: "msg-1",
    sessionId: "chat-1",
    role: "user",
    type: "text",
    content: "帮我执行生产环境部署",
    timestamp: "2024-03-10T14:00:00Z",
  },
  {
    id: "msg-2",
    sessionId: "chat-1",
    role: "assistant",
    type: "text",
    content: "好的，我将为您执行 Deploy Production 工作流。这将包括以下步骤：\n\n1. 拉取最新代码\n2. 安装依赖\n3. 运行测试\n4. 构建应用\n5. 部署到服务器\n\n确认执行吗？",
    timestamp: "2024-03-10T14:00:05Z",
  },
  {
    id: "msg-3",
    sessionId: "chat-1",
    role: "user",
    type: "command",
    content: "确认执行",
    timestamp: "2024-03-10T14:00:10Z",
  },
  {
    id: "msg-4",
    sessionId: "chat-1",
    role: "assistant",
    type: "execution",
    content: "已启动工作流执行",
    timestamp: "2024-03-10T14:00:12Z",
    metadata: {
      executionId: "exec-1",
    },
  },
]

// ============ File Tree ============
export const mockFileTree: FileNode[] = [
  {
    id: "f1",
    name: "src",
    type: "directory",
    path: "/src",
    isExpanded: true,
    children: [
      {
        id: "f2",
        name: "components",
        type: "directory",
        path: "/src/components",
        isExpanded: false,
        children: [
          { id: "f3", name: "Button.tsx", type: "file", path: "/src/components/Button.tsx", extension: "tsx" },
          { id: "f4", name: "Card.tsx", type: "file", path: "/src/components/Card.tsx", extension: "tsx" },
        ],
      },
      {
        id: "f5",
        name: "pages",
        type: "directory",
        path: "/src/pages",
        isExpanded: false,
        children: [
          { id: "f6", name: "index.tsx", type: "file", path: "/src/pages/index.tsx", extension: "tsx" },
          { id: "f7", name: "about.tsx", type: "file", path: "/src/pages/about.tsx", extension: "tsx" },
        ],
      },
      { id: "f8", name: "App.tsx", type: "file", path: "/src/App.tsx", extension: "tsx" },
      { id: "f9", name: "main.tsx", type: "file", path: "/src/main.tsx", extension: "tsx" },
    ],
  },
  {
    id: "f10",
    name: "workflows",
    type: "directory",
    path: "/workflows",
    isExpanded: true,
    children: [
      { id: "f11", name: "deploy.yaml", type: "file", path: "/workflows/deploy.yaml", extension: "yaml" },
      { id: "f12", name: "migrate.yaml", type: "file", path: "/workflows/migrate.yaml", extension: "yaml" },
      { id: "f13", name: "test.yaml", type: "file", path: "/workflows/test.yaml", extension: "yaml" },
    ],
  },
  { id: "f14", name: "package.json", type: "file", path: "/package.json", extension: "json" },
  { id: "f15", name: "README.md", type: "file", path: "/README.md", extension: "md" },
]

// ============ Dashboard Stats ============
export const mockDashboardStats: DashboardStats = {
  activeWorkspaces: 3,
  totalWorkspaces: 5,
  runningExecutions: 2,
  queuedExecutions: 1,
  completedToday: 8,
  failedToday: 1,
}

// ============ Helper Functions ============
export function getWorkspaceById(id: string): Workspace | undefined {
  return mockWorkspaces.find((ws) => ws.id === id)
}

export function getExecutionsByWorkspace(workspaceId: string): Execution[] {
  return mockExecutions.filter((exec) => exec.workspaceId === workspaceId)
}

export function getRunningExecutions(): Execution[] {
  return mockExecutions.filter((exec) => exec.status === "running")
}

export function getQueuedExecutions(): Execution[] {
  return mockExecutions.filter((exec) => exec.status === "queued")
}

export function getRecentExecutions(limit: number = 10): Execution[] {
  return [...mockExecutions]
    .sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime())
    .slice(0, limit)
}

export function getWorkflowsByWorkspace(workspaceId: string): Workflow[] {
  return mockWorkflows.filter((wf) => wf.workspaceId === workspaceId)
}

export function getChatSessionsByWorkspace(workspaceId: string): ChatSession[] {
  return mockChatSessions.filter((session) => session.workspaceId === workspaceId)
}

export function getMessagesBySession(sessionId: string): ChatMessage[] {
  return mockChatMessages.filter((msg) => msg.sessionId === sessionId)
}
