// Octopus Web UI - Core Types

// ============ Workspace ============
export type WorkspaceStatus = "active" | "inactive" | "error"

export interface Workspace {
  id: string
  name: string
  description: string
  status: WorkspaceStatus
  projectCount: number
  workflowCount: number
  createdAt: string
  updatedAt: string
  lastActivityAt: string
  path: string // Local filesystem path
}

// ============ Project ============
export interface Project {
  id: string
  workspaceId: string
  name: string
  path: string
  description: string
  createdAt: string
  updatedAt: string
}

// ============ Workflow ============
export type WorkflowStatus = "valid" | "invalid" | "draft"

export interface WorkflowStep {
  id: string
  name: string
  type: "shell" | "script" | "api" | "condition" | "loop"
  command?: string
  description?: string
  dependsOn?: string[]
}

export interface Workflow {
  id: string
  projectId: string
  workspaceId: string
  name: string
  description: string
  status: WorkflowStatus
  steps: WorkflowStep[]
  yamlContent: string
  createdAt: string
  updatedAt: string
}

// ============ Execution ============
export type ExecutionStatus = "queued" | "running" | "completed" | "failed" | "cancelled" | "rolling_back"

export type StepExecutionStatus = "pending" | "running" | "completed" | "failed" | "skipped"

export interface StepExecution {
  stepId: string
  stepName: string
  status: StepExecutionStatus
  startedAt?: string
  completedAt?: string
  duration?: number // in seconds
  output?: string
  error?: string
}

export interface Execution {
  id: string
  workflowId: string
  workflowName: string
  workspaceId: string
  workspaceName: string
  status: ExecutionStatus
  progress: number // 0-100
  currentStep?: string
  steps: StepExecution[]
  startedAt: string
  completedAt?: string
  duration?: number // in seconds
  triggeredBy: "manual" | "schedule" | "webhook" | "chat"
  logs: string[]
}

// ============ Chat ============
export type MessageRole = "user" | "assistant" | "system"
export type MessageType = "text" | "command" | "execution" | "error" | "file"

export interface ChatMessage {
  id: string
  sessionId: string
  role: MessageRole
  type: MessageType
  content: string
  timestamp: string
  metadata?: {
    executionId?: string
    filePath?: string
    command?: string
  }
}

export interface ChatSession {
  id: string
  workspaceId: string
  title: string
  messages: ChatMessage[]
  createdAt: string
  updatedAt: string
  isActive: boolean
}

// ============ File Tree ============
export type FileNodeType = "file" | "directory"

export interface FileNode {
  id: string
  name: string
  type: FileNodeType
  path: string
  children?: FileNode[]
  isExpanded?: boolean
  extension?: string
}

// ============ Dashboard Stats ============
export interface DashboardStats {
  activeWorkspaces: number
  totalWorkspaces: number
  runningExecutions: number
  queuedExecutions: number
  completedToday: number
  failedToday: number
}

// ============ API Response Types ============
export interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

export interface PaginatedResponse<T> {
  items: T[]
  total: number
  page: number
  pageSize: number
  hasMore: boolean
}
