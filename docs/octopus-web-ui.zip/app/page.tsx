import { StatsCards } from "@/components/dashboard/stats-cards"
import { QueuePanel } from "@/components/dashboard/queue-panel"
import { RecentExecutions } from "@/components/dashboard/recent-executions"
import {
  mockDashboardStats,
  getRunningExecutions,
  getQueuedExecutions,
  getRecentExecutions,
} from "@/lib/mock-data"

export default function DashboardPage() {
  const stats = mockDashboardStats
  const runningExecutions = getRunningExecutions()
  const queuedExecutions = getQueuedExecutions()
  const recentExecutions = getRecentExecutions(10)

  return (
    <div className="container mx-auto space-y-6 px-4 py-6 lg:px-6">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          工作流编排平台概览
        </p>
      </div>

      {/* Stats Cards */}
      <StatsCards stats={stats} />

      {/* Main Content Grid */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Queue Panel */}
        <QueuePanel
          runningExecutions={runningExecutions}
          queuedExecutions={queuedExecutions}
        />

        {/* Recent Executions */}
        <RecentExecutions executions={recentExecutions} />
      </div>
    </div>
  )
}
