"use client"

import { use, useState } from "react"
import { notFound } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { SidebarFileTree } from "@/components/workspace/sidebar-file-tree"
import { ChatPanel } from "@/components/workspace/chat-panel"
import { WorkflowFlowPanel } from "@/components/workspace/workflow-flow-panel"
import {
  getWorkspaceById,
  getExecutionsByWorkspace,
  getWorkflowsByWorkspace,
  getChatSessionsByWorkspace,
  mockFileTree,
  mockChatMessages,
} from "@/lib/mock-data"
import type { FileNode, ChatMessage, ChatSession, Execution } from "@/lib/types"
import {
  PanelLeftClose,
  PanelRightClose,
  Settings,
  Play,
} from "lucide-react"

interface WorkspaceDetailPageProps {
  params: Promise<{ id: string }>
}

export default function WorkspaceDetailPage({ params }: WorkspaceDetailPageProps) {
  const { id } = use(params)
  const workspace = getWorkspaceById(id)

  // Get workspace data
  const workflows = getWorkflowsByWorkspace(id)
  const executions = getExecutionsByWorkspace(id)
  const chatSessions = getChatSessionsByWorkspace(id)

  // Add default session if none exist
  const sessions: ChatSession[] = chatSessions.length > 0 ? chatSessions : [
    {
      id: "default-session",
      workspaceId: id,
      title: "新会话",
      messages: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      isActive: true,
    },
  ]

  const [showFileTree, setShowFileTree] = useState(true)
  const [showChat, setShowChat] = useState(true)
  const [selectedFile, setSelectedFile] = useState<FileNode | null>(null)
  const [selectedExecution, setSelectedExecution] = useState<Execution | null>(null)
  const [activeSessionId, setActiveSessionId] = useState(sessions[0]?.id || "")
  const [messages, setMessages] = useState<ChatMessage[]>(mockChatMessages)
  const [allSessions, setAllSessions] = useState<ChatSession[]>(sessions)

  if (!workspace) {
    notFound()
  }

  const handleFileSelect = (file: FileNode) => {
    setSelectedFile(file)
  }

  const handleExecutionSelect = (execution: Execution) => {
    setSelectedExecution(execution)
  }

  const handleSessionChange = (sessionId: string) => {
    setActiveSessionId(sessionId)
  }

  const handleCreateSession = () => {
    const newSession: ChatSession = {
      id: `session-${Date.now()}`,
      workspaceId: id,
      title: `会话 ${allSessions.length + 1}`,
      messages: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      isActive: true,
    }
    setAllSessions((prev) => [...prev, newSession])
    setActiveSessionId(newSession.id)
    setMessages([])
  }

  const handleCloseSession = (sessionId: string) => {
    if (allSessions.length <= 1) return
    setAllSessions((prev) => prev.filter((s) => s.id !== sessionId))
    if (activeSessionId === sessionId) {
      const remaining = allSessions.filter((s) => s.id !== sessionId)
      setActiveSessionId(remaining[0]?.id || "")
    }
  }

  const handleSendMessage = (content: string) => {
    const newMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      sessionId: activeSessionId,
      role: "user",
      type: "text",
      content,
      timestamp: new Date().toISOString(),
    }
    setMessages((prev) => [...prev, newMessage])

    // Simulate assistant response
    setTimeout(() => {
      const assistantMessage: ChatMessage = {
        id: `msg-${Date.now()}-assistant`,
        sessionId: activeSessionId,
        role: "assistant",
        type: "text",
        content: `收到您的消息："${content}"。我正在处理中...`,
        timestamp: new Date().toISOString(),
      }
      setMessages((prev) => [...prev, assistantMessage])
    }, 1000)
  }

  return (
    <div className="flex h-[calc(100vh-3.5rem)] flex-col">
      {/* Workspace Header */}
      <div className="flex h-11 items-center justify-between border-b border-border px-4 bg-background">
        <div className="flex items-center gap-3">
          <h1 className="font-semibold">{workspace.name}</h1>
          <Badge variant={workspace.status === "active" ? "default" : "secondary"}>
            {workspace.status === "active" ? "活跃" : workspace.status === "error" ? "异常" : "未激活"}
          </Badge>
          {selectedExecution && (
            <>
              <span className="text-muted-foreground">/</span>
              <span className="text-sm text-muted-foreground">
                执行 #{selectedExecution.id.slice(-4)}
              </span>
            </>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={() => setShowFileTree(!showFileTree)}>
            <PanelLeftClose className="h-4 w-4" />
            <span className="sr-only">切换文件树</span>
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setShowChat(!showChat)}>
            <PanelRightClose className="h-4 w-4" />
            <span className="sr-only">切换聊天</span>
          </Button>
          <Button variant="outline" size="sm">
            <Settings className="mr-2 h-4 w-4" />
            设置
          </Button>
          <Button size="sm">
            <Play className="mr-2 h-4 w-4" />
            执行工作流
          </Button>
        </div>
      </div>

      {/* Three-column layout: File Tree | Workflow Flow | Chat */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left: File Tree */}
        {showFileTree && (
          <div className="w-56 flex-shrink-0">
            <SidebarFileTree
              files={mockFileTree}
              onFileSelect={handleFileSelect}
              selectedPath={selectedFile?.path}
            />
          </div>
        )}

        {/* Center: Workflow Flow Panel (Dify-style) */}
        <div className="flex-1 min-w-0">
          <WorkflowFlowPanel
            workflows={workflows}
            executions={executions}
            selectedExecutionId={selectedExecution?.id}
            onExecutionSelect={handleExecutionSelect}
          />
        </div>

        {/* Right: Session Tabs + Chat Panel */}
        {showChat && (
          <div className="w-80 flex-shrink-0">
            <ChatPanel
              sessions={allSessions}
              activeSessionId={activeSessionId}
              messages={messages}
              onSessionChange={handleSessionChange}
              onCreateSession={handleCreateSession}
              onCloseSession={handleCloseSession}
              onSendMessage={handleSendMessage}
            />
          </div>
        )}
      </div>
    </div>
  )
}
