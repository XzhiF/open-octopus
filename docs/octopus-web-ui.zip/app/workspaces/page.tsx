import { WorkspaceList } from "@/components/workspaces/workspace-list"
import { mockWorkspaces } from "@/lib/mock-data"

export default function WorkspacesPage() {
  return (
    <div className="container mx-auto px-4 py-6 lg:px-6">
      {/* Page Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight">工作空间</h1>
        <p className="text-muted-foreground">
          管理您的工作空间、项目和工作流
        </p>
      </div>

      {/* Workspace List */}
      <WorkspaceList workspaces={mockWorkspaces} />
    </div>
  )
}
